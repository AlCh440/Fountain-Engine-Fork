# Fountian Engine

## Descrtiption
Fountain engine is a new engine specifically designed for videogames, in c++ for learning purposes.

This Engine has been created in the CITM subject "Engines" by 2 members in the 3rd course. The main objective of this project is to learn and improve our programming skills. To do our engine we have implmented what we have learned this year in this subject, and also we had to use our knowledge learned through the course. Actually isn't the most optimized engine on the market, but one day it will be as powerfull as other engines.

This engine is completely free.

To access the main webpage of the Fountain Engine, click the following link: https://github.com/AlCh440/EngineBrumBrum/blob/main/README.md
## Members
Fountain Engine is being programmed and created by two students from the CITM:

·Albert Chica Ferrer // Github: https://github.com/AlCh440

·Juan Fernando Almendro Martí // Github: https://github.com/FernaToty
## Controls

### Movement controls:

·W Move forward

·A Move left

·S Move backwards

·D Move right

·Q Move up

·E Move Down

·Shift Move faster

·Right click Rotate the screen

·Mouse Whell ZOOM

·F Centers to object

·CTRL S Save scene

## Things you should know!

Camera controls are weird, both cameras are shown throug the same screen, buttons on top of that screen change between them

## Additional Functionalities

No information yet

## License

MIT License

Copyright (c) 2022 AlCh440

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
